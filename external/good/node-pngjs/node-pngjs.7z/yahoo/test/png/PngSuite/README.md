Some of these PNG test-files are form the PngSuite created by Willem van Schaik.
All other files were created to tests PNGjs-Image and are under the same license as the source-code (see LICENSE in the project root).

Files:
* xxdxdxdd.png - Files are from PngSuite created by Willem van Schaik - See PngSuite.LICENSE for more details
* xxdxdxdd.raw - Raw data dump of an image in TrueColor with Alpha-Channel; uncompressed, 4 samples each having 8-bits - lossy down-scaled from 16-bits when needed
* xxdxdxdd_TrueColor.png - TrueColor with Alpha-Channel using only filter 0 and nbo interlace to reduce cross-functional tests
* base.raw - Basic image file (32x32 pixel) in black and white using TrueColor with Alpha-Channel - Easy to read in hex-editor since it only has values 0 and 255. Used as image when writing chunks that are not directly affecting the image like tEXt chunks.
