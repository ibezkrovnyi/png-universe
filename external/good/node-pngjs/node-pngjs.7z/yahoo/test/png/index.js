// Copyright 2015 Yahoo! Inc.
// Copyrights licensed under the Mit License. See the accompanying LICENSE file for terms.

describe('PNG', function () {

	require('./utils');

	require('./decode');
	require('./encode');
});
