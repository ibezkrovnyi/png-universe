// Copyright 2015 Yahoo! Inc.
// Copyrights licensed under the Mit License. See the accompanying LICENSE file for terms.

var testGen = require('../../testGen');
var expect = require('chai').expect;

//ps1n0g08 - six-cube suggested palette (1 byte) in grayscale image
//ps1n2c16 - six-cube suggested palette (1 byte) in true-color image
//ps2n0g08 - six-cube suggested palette (2 bytes) in grayscale image
//ps2n2c16 - six-cube suggested palette (2 bytes) in true-color image
describe('Suggested Palette', function () {
	//TODO
});
