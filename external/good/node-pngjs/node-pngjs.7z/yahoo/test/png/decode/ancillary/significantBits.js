// Copyright 2015 Yahoo! Inc.
// Copyrights licensed under the Mit License. See the accompanying LICENSE file for terms.

var testGen = require('../../testGen');
var expect = require('chai').expect;

//cs3n2c16 - color, 13 significant bits
//cs3n3p08 - paletted, 3 significant bits
//cs5n2c08 - color, 5 significant bits
//cs5n3p08 - paletted, 5 significant bits
//cs8n2c08 - color, 8 significant bits (reference)
//cs8n3p08 - paletted, 8 significant bits (reference)
describe('Significant Bits', function () {
	//TODO
});
