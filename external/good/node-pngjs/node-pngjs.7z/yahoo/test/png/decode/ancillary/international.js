// Copyright 2015 Yahoo! Inc.
// Copyrights licensed under the Mit License. See the accompanying LICENSE file for terms.

var testGen = require('../../testGen');
var expect = require('chai').expect;

//cten0g04 - international UTF-8, english
//ctfn0g04 - international UTF-8, finnish
//ctgn0g04 - international UTF-8, greek
//cthn0g04 - international UTF-8, hindi
//ctjn0g04 - international UTF-8, japanese
describe('International Text', function () {
	//TODO
});
